import 'package:flutter/material.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

class YourPageViewWidget extends StatefulWidget {
  @override
  _YourPageViewWidgetState createState() => _YourPageViewWidgetState();
}
List<SaleList> saleList = [];
List<newReleaseItems> items = [];
class _YourPageViewWidgetState extends State<YourPageViewWidget> {
  salesList() {
    saleList.clear();
    saleList.add(SaleList(images: "assets/images/sales/sale.png"));
    saleList.add(SaleList(images: "assets/images/sales/clothes.png"));
    saleList.add(SaleList(images: "assets/images/sales/home.png"));
    saleList.add(SaleList(images: "assets/images/sales/coming.png"));
    setState(() {});
  }

  @override
  void initState() {
    // TODO: implement initState
    salesList();

    super.initState();
  }
  // Initialize the PageController
  PageController controller = PageController(viewportFraction: 1);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          PageView.builder(
            itemCount: saleList.length,  // Ensure this is not empty
            controller: controller,
            onPageChanged: (index) {
              setState(() {
                // Optionally, update any state here when page changes
              });
            },
            itemBuilder: (BuildContext context, int index) {
              return Container(
                decoration: BoxDecoration(
                  shape: BoxShape.rectangle,
                  image: DecorationImage(
                    image: AssetImage(saleList[index].images),  // Ensure this image path is correct
                    fit: BoxFit.cover,
                  ),
                ),
              );
            },
          ),
          Positioned(
            bottom: 50,
            left: 160,
            right: 0,
            child: SmoothPageIndicator(
              controller: controller,  // Sync the controller
              count: saleList.length,
              effect: const ExpandingDotsEffect(
                dotHeight: 8.0,
                dotWidth: 8.0,
                spacing: 4.0,
                activeDotColor: Colors.white,
              ),
            ),
          ),

        ],
      ),
    );
  }
}

class SaleList {
  String images;

  SaleList({required this.images});
}
class newReleaseItems{
  String images;
  String name;
  String price;
  newReleaseItems({required this.name,required this.images,required this.price});
}
class NewReleaseItems extends StatefulWidget {
  @override
  _NewReleaseItems createState() => _NewReleaseItems();
}
class _NewReleaseItems extends State<NewReleaseItems> {
  releasedItems(){
    items.clear();
    items.add(newReleaseItems(name: "Airpods Pro 4[Active Noise Cancellation]", images: "assets/images/sales/airpods.png", price: "17,900 Rs."));
    items.add(newReleaseItems(name: "Apple Watch Series 10[GPS 42 mm] Smartwatch", images: "assets/images/sales/applewatch.png", price: "46,900 RS."));
    setState(() {

    });
  }
  @override
  void initState() {
    // TODO: implement initState
    releasedItems();
    super.initState();
  }
  // Initialize the PageController
  PageController controller = PageController(viewportFraction: 1);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          PageView.builder(
            itemCount: items.length,  // Ensure this is not empty
            controller: controller,
            onPageChanged: (index) {
              setState(() {
                // Optionally, update any state here when page changes
              });
            },
            itemBuilder: (BuildContext context, int index) {
              return Column(crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    height:240,
                    decoration: BoxDecoration(
                      shape: BoxShape.rectangle,
                      image: DecorationImage(
                        image: AssetImage(items[index].images),  // Ensure this image path is correct
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 15,bottom: 5,top: 5),
                    child: Text(items[index].name,overflow: TextOverflow.ellipsis,maxLines: 1,),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left:15),
                    child: Text(items[index].price),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 15,top: 5),
                    child: _addToCartButton,
                  )
                ],
              );
            },
          ),
          Positioned(
            bottom: 120,
            left: 170,
            right: 0,
            child: SmoothPageIndicator(
              controller: controller,  // Sync the controller
              count: items.length,
              effect: const ExpandingDotsEffect(
                dotHeight: 8.0,
                dotWidth: 8.0,
                spacing: 4.0,
                activeDotColor: Colors.white,
              ),
            ),
          ),

        ],
      ),
    );
  }
}
Widget get _addToCartButton => SizedBox(
  height: 30,
  width: 120,
  child: Builder(builder: (context) {
    return ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.amber,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20.0),
          ), // Background color
        ),
        onPressed: () {

        },
        child: const Text(
          "Add to cart",
          style: TextStyle(color: Colors.black,
               overflow: TextOverflow.ellipsis),
          maxLines: 1,
        ));
  }),
);