import 'dart:ui';

import 'package:amazon/customappbar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class MenuPage extends StatefulWidget {
  const MenuPage({super.key});

  @override
  State<MenuPage> createState() => _MenuPageState();
}

List<MenuItems> itemsList = [];

class _MenuPageState extends State<MenuPage> {
  menuItemList() {
    itemsList.clear();
    itemsList.add(MenuItems(
        name: "Mobiles & Electronics ",
        image: "assets/images/hpOptionlist/electronics.png"));
    itemsList.add(MenuItems(
        name: "Fashion & Beauty",
        image: "assets/images/hpOptionlist/fashion.png"));
    itemsList.add(MenuItems(
        name: "Groceries", image: "assets/images/hpOptionlist/grocery.png"));
    itemsList.add(MenuItems(
        name: "Home,Furniture &\nDecor",
        image: "assets/images/hpOptionlist/home.png"));
    itemsList.add(MenuItems(
        name: "Travel & Auto", image: "assets/images/hpOptionlist/travel.png"));
    itemsList.add(MenuItems(
        name: "Gifting", image: "assets/images/hpOptionlist/gifting.png"));
    itemsList.add(MenuItems(
        name: "Prime", image: "assets/images/hpOptionlist/prime.png"));
    itemsList.add(MenuItems(
        name: "Toys & Children", image: "assets/images/hpOptionlist/toys.png"));
    itemsList.add(MenuItems(
        name: "Sports & Fitness",
        image: "assets/images/hpOptionlist/fitness.png"));
    itemsList.add(MenuItems(
        name: "Amazon Pay", image: "assets/images/hpOptionlist/amazonpay.png"));
    setState(() {});
  }

  @override
  void initState() {
    // TODO: implement initState
    menuItemList();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            CustomAppBar(),
            _MenuItemsWidget,
            _SwitchAccountWidget,
            _SignOutWidget,
            _CustomerServiceWidget


          ],
        ),
      ),
    ));
  }
}

Widget get _MenuItemsWidget => GridView.builder(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2, // number of items in each row
        mainAxisSpacing: 8.0, // spacing between rows
        crossAxisSpacing: 8.0,
        // spacing between columns
      ),
      padding: const EdgeInsets.all(8.0),
      // padding around the grid
      itemCount: itemsList.length,
      // total number of items
      itemBuilder: (context, index) {
        return Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            shape: BoxShape.rectangle,
            border: Border.all(width: 1, color: Colors.grey),
            //color: Colors.grey[50],
            // gradient: LinearGradient(colors: [
            //   Colors.tealAccent[100]!,
            //   Colors.teal[50]!,
            // ]),
            // boxShadow: [
            //   BoxShadow(
            //     offset: Offset(0, 0),
            //     color: Colors.teal[50]!,
            //     blurRadius: 16.0,
            //   ),
            // ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  itemsList[index].name,
                  style: TextStyle(overflow: TextOverflow.ellipsis),
                  maxLines: 1,
                ),
              ),
              Center(
                child: Container(
                  margin: EdgeInsets.all(10),
                  width: 110,
                  height: 110,
                  decoration: BoxDecoration(
                    shape: BoxShape.rectangle,
                    image: DecorationImage(
                        image: AssetImage(itemsList[index].image),
                        fit: BoxFit.contain),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );

Widget get _SwitchAccountWidget => Padding(
  padding: const EdgeInsets.all(8.0),
  child: SizedBox(
        height: 40,
        width: 375,
        child: Builder(builder: (context) {
          return ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white,
                side: BorderSide(
                  color: Colors.grey,
                  width: 0.5,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5.0),
                ), // Background color
              ),
              onPressed: () {

              },
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      "Switch Accounts",
                      style: TextStyle(
                          color: Colors.black, overflow: TextOverflow.ellipsis),
                      maxLines: 1,
                    ),
                  ),
                  Icon(
                    (Icons.arrow_forward_ios),
                    size: 15,color: Colors.black,
                  )
                ],
              ));
        }),
      ),
);
Widget get _SignOutWidget => Padding(
  padding: const EdgeInsets.all(8.0),
  child: SizedBox(
    height: 40,
    width: 375,
    child: Builder(builder: (context) {
      return ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.white,
            side: BorderSide(
              color: Colors.grey,
              width: 0.5,
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(5.0),
            ), // Background color
          ),
          onPressed: () {

          },
          child: Row(
            children: [
              Expanded(
                child: Text(
                  "Sign Out",
                  style: TextStyle(
                      color: Colors.black, overflow: TextOverflow.ellipsis),
                  maxLines: 1,
                ),
              ),
              Icon(
                (Icons.arrow_forward_ios),
                size: 15,color: Colors.black,
              )
            ],
          ));
    }),
  ),
);
Widget get _CustomerServiceWidget => Padding(
  padding: const EdgeInsets.all(8.0),
  child: SizedBox(
    height: 40,
    width: 375,
    child: Builder(builder: (context) {
      return ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.white,
            side: BorderSide(
              color: Colors.grey,
              width: 0.5,
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(5.0),
            ), // Background color
          ),
          onPressed: () {

          },
          child: Row(
            children: [
              Expanded(
                child: Text(
                  "Customer Service",
                  style: TextStyle(
                      color: Colors.black, overflow: TextOverflow.ellipsis),
                  maxLines: 1,
                ),
              ),
              Icon(
                (Icons.arrow_forward_ios),
                size: 15,color: Colors.black,
              )
            ],
          ));
    }),
  ),
);

class MenuItems {
  String name;
  String image;

  MenuItems({required this.name, required this.image});
}
