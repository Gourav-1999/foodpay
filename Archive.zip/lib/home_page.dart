import 'package:amazon/customappbar.dart';
import 'package:amazon/sales_ads.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

var size, height, width;

PageController controller = PageController(viewportFraction: 1);
List<OptionList> opList = [];
List<SaleList> saleList = [];
List<CardList> cardItems = [];
List<DealsList> dealItems = [];
class _HomePageState extends State<HomePage> {
  optionList() {
    opList.clear();
    opList.add(OptionList(
        images: "assets/images/hpOptionlist/grocery.png", name: "Groceries"));
    opList.add(OptionList(
        images: "assets/images/hpOptionlist/prime.png", name: "Prime"));
    opList.add(OptionList(
        images: "assets/images/hpOptionlist/home.png", name: "Home"));
    opList.add(OptionList(
        images: "assets/images/hpOptionlist/fashion.png", name: "Fashion"));
    opList.add(OptionList(
        images: "assets/images/hpOptionlist/electronics.png",
        name: "Electronics"));
    opList.add(OptionList(
        images: "assets/images/hpOptionlist/deals.png", name: "Deals"));
    opList.add(OptionList(
        images: "assets/images/hpOptionlist/mobile.png", name: "Mobiles"));
    opList.add(OptionList(
        images: "assets/images/hpOptionlist/bazaar.png", name: "Bazaar"));
    opList.add(OptionList(
        images: "assets/images/hpOptionlist/beauty.png", name: "Beauty"));
    opList.add(OptionList(
        images: "assets/images/hpOptionlist/giftcards.png",
        name: "Gift cards"));
    opList.add(OptionList(
        images: "assets/images/hpOptionlist/health.png", name: "Health"));
    opList.add(OptionList(
        images: "assets/images/hpOptionlist/travel.png", name: "Travel"));
    opList.add(OptionList(
        images: "assets/images/hpOptionlist/movie.png", name: "Movies"));
    setState(() {});
  }

  cardList() {
    cardItems.clear();
    cardItems.add(CardList(name: "", image: ""));
    cardItems.add(CardList(name: "Keep shopping for\nLaptops", image: "assets/images/shopping/mac.png"));
    cardItems.add(CardList(name: "Recommended deal\nfor you", image: "assets/images/shopping/rolex.png"));
    cardItems.add(CardList(name: "", image: ""));
    cardItems.add(CardList(name: "Keep shopping for\nPerfumes", image: "assets/images/shopping/perfume.png"));
    cardItems.add(CardList(name: "Buy it again", image: "assets/images/shopping/iphone.png"));
    cardItems.add(CardList(name: "4+ star deals", image: "assets/images/shopping/ipad.png"));
    setState(() {});
  }

  dealList(){
    dealItems.clear();
    dealItems.add(DealsList(discount: "25% off", image: "assets/images/dealsforyou/hoody.png"));
    dealItems.add(DealsList(discount: "40% off", image: "assets/images/dealsforyou/pent.png"));
    dealItems.add(DealsList(discount: "60% off", image: "assets/images/dealsforyou/shoes.png"));
    dealItems.add(DealsList(discount: "25% off", image: "assets/images/dealsforyou/blazer.png"));
    dealItems.add(DealsList(discount: "45% off", image: "assets/images/dealsforyou/tshirt.png"));
    dealItems.add(DealsList(discount: "20% off", image: "assets/images/dealsforyou/sunglasses.png"));
    dealItems.add(DealsList(discount: "45% off", image: "assets/images/dealsforyou/purse.png"));
    dealItems.add(DealsList(discount: "50% off", image: "assets/images/dealsforyou/coatpent.png"));
    setState(() {

    });
  }
  @override
  void initState() {
    // TODO: implement initState
    optionList();
    cardList();
    dealList();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    height = size.height;
    width = size.width;
    return SafeArea(
        child: Scaffold(
      body: SingleChildScrollView(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CustomAppBar(),
            _selectLocation,
            const SizedBox(
              height: 10,
            ),
            _selectItems,
            const Divider(thickness: 2,height: 3,),
            SizedBox(height: height / 3, child: YourPageViewWidget()),
            const Divider(thickness: 2,height: 1,),
            SizedBox(height:height / 4,child: _selectCardItems),
            const Divider(thickness: 2,height: 1,),
            SizedBox(height: height/2.2,child: NewReleaseItems(),),
            Padding(
              padding: const EdgeInsets.only(left: 10),
              child: const Text("Deals for you",style: TextStyle(fontWeight: FontWeight.bold,),maxLines: 1,),
            ),
            SizedBox(height: height,
                child:_dealsForYouWidget),
        
          ],
        ),
      ),
    ));
  }
}

Widget get _selectLocation => Container(
      height: height / 18,
      decoration: BoxDecoration(color: Colors.tealAccent[100]),
      child: const Row(
        children: [
          Icon(Icons.location_on),
          Text(
            "Deliver to Joker - DholakPur 11111",
            style: TextStyle(overflow: TextOverflow.ellipsis),
            maxLines: 1,
          ),
          Icon(Icons.arrow_drop_down)
        ],
      ),
    );
Widget get _selectItems => SizedBox(
      height: height / 11,
      child: ListView.builder(
          shrinkWrap: true,
          scrollDirection: Axis.horizontal,
          itemCount: opList.length,
          itemBuilder: (context, index) {
            return GestureDetector(
              onTap: () {
                print("hiii");
              },
              child: Column(
                children: [
                  Container(
                    height: 40,
                    width: 40,
                    margin: const EdgeInsets.only(top: 3),
                    decoration: BoxDecoration(
                      shape: BoxShape.rectangle,
                      image: DecorationImage(
                          image: AssetImage(opList[index].images),
                          fit: BoxFit.contain),
                    ),
                  ),
                  const SizedBox(
                    height: 4,
                  ),
                  SizedBox(
                      width: 70,
                     height: 15,
                      child: Text(
                        opList[index].name,
                        textAlign: TextAlign.center,
                      ))
                ],
              ),
            );
          }),
    );

Widget get _selectCardItems => ListView.builder(
    itemCount: cardItems.length,
    shrinkWrap: true,
    scrollDirection: Axis.horizontal,
    itemBuilder: (context,index){
return index==0?SizedBox(
  width: 200,
  child: Card(
    elevation: 3,
    margin: EdgeInsets.only(left: 10,right: 5,bottom: 10),
      surfaceTintColor: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(2),
      ),
      child: Padding(
        padding: const EdgeInsets.only(top: 10),
        child: Column(

          children: [
            Row(mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 10),
                  child: Column(
                    children: [
                      Container(
                        margin: EdgeInsets.all(5),
                        width: 40,
                        height: 40,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          image: DecorationImage(
                              image: AssetImage("assets/icons/amazon-pay.png"),
                              fit: BoxFit.cover),
                        ),
                      ),
                      const Text(
                        "Amazon Pay",
                        style: TextStyle(fontSize: 10),
                      ),
                    ],
                  ),
                ),
               Spacer(),
                Padding(
                  padding: const EdgeInsets.only(right: 20),
                  child: Column(
                    children: [
                      Container(
                        margin: EdgeInsets.all(5),
                        width: 40,
                        height: 40,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.amber,
                          image: DecorationImage(
                              image: AssetImage("assets/icons/send.png"),
                              fit: BoxFit.cover),
                        ),
                      ),
                      const Text(
                        "Send Money",
                        style: TextStyle(fontSize: 10),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Row(mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 10),
                  child: Column(
                    children: [
                      Container(
                        margin: EdgeInsets.all(5),
                        width: 40,
                        height: 40,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          image: DecorationImage(
                              image: AssetImage( "assets/icons/qr-code.png"),
                              fit: BoxFit.cover),
                        ),
                      ),
                      const Text(
                        "Scan any QR",
                        style: TextStyle(fontSize: 10),
                      ),
                    ],
                  ),
                ),
               Spacer(),
                Padding(
                  padding: const EdgeInsets.only(right: 10),
                  child: Column(
                    children: [
                      Container(
                        margin: EdgeInsets.all(5),
                        width: 40,
                        height: 40,
                        decoration: const BoxDecoration(
                          color: Colors.amber,
                          shape: BoxShape.circle,
                          image: DecorationImage(
                              image: AssetImage("assets/icons/mobile.png"),
                              fit: BoxFit.cover),
                        ),
                      ),
                      const Text(
                        "Recharge & Bills",
                        style: TextStyle(fontSize: 10),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      )
  ),
):index==3?
SizedBox(
  width: 180,
  child: Card(
    elevation: 3,

    color: Colors.yellow,
    margin: EdgeInsets.only(left: 10,right: 5,bottom: 10),
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(2),
    ),
    child: Column(
      children: [
        SizedBox(
            height: 40,
            child: Text("Reveal scratch card\nnow",maxLines: 2,textAlign: TextAlign.center,)),
        Divider(),
        Container(
          width: 100,
          height: 100,
          decoration:  BoxDecoration(
            shape: BoxShape.rectangle,
            image: DecorationImage(
                image: AssetImage("assets/icons/gift-card.png"),
                fit: BoxFit.contain),
          ),
        ),
      ],
    ),
  ),
):
SizedBox(
  width: 180,
  child: Card(
    elevation: 3,
    surfaceTintColor: Colors.white,
      margin: EdgeInsets.only(left: 10,right: 5,bottom: 10),
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(2),
    ),
    child: Column(
      children: [
        SizedBox(
            height: 40,
            child: Text(cardItems[index].name,maxLines: 2,textAlign: TextAlign.center,)),
        Divider(),
        Container(
          width: 100,
          height: 100,
          decoration:  BoxDecoration(
            shape: BoxShape.rectangle,
            image: DecorationImage(
                image: AssetImage(cardItems[index].image),
                fit: BoxFit.contain),
          ),
        ),
      ],
    )
  ),
);

});
Widget get _dealsForYouWidget=>GridView.builder(
  shrinkWrap: true,
  physics: NeverScrollableScrollPhysics(),
  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
    crossAxisCount: 2, // number of items in each row
    mainAxisSpacing: 8.0, // spacing between rows
    crossAxisSpacing: 8.0, // spacing between columns
  ),
  padding: const EdgeInsets.all(8.0), // padding around the grid
  itemCount: dealItems.length, // total number of items
  itemBuilder: (context, index) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(5),
        shape: BoxShape.rectangle,
        color: Colors.grey[50]
      ),
      child: Column(
        children: [
          Container(
            width: 120,
            height: 120,
            decoration:  BoxDecoration(
              shape: BoxShape.rectangle,
              image: DecorationImage(
                  image: AssetImage(dealItems[index].image),
                  fit: BoxFit.contain),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Container(
                  decoration: const BoxDecoration(
                    color: Colors.red,
                    shape: BoxShape.rectangle,
                  ),
                  child: Text(dealItems[index].discount,style: const TextStyle(color: Colors.white),),
                ),
                const SizedBox(width: 5,),
                const Text("Limited time deal",style: TextStyle(color: Colors.red,fontSize: 12),maxLines: 1,)
              ],
            ),
          ),
        ],
      ),
    );
  },
);


class OptionList {
  String images;
  String name;

  OptionList({required this.images, required this.name});
}
class CardList {
  String name;
  String image;

  CardList({required this.name, required this.image});
}
class DealsList{
  String discount;
  String image;
  DealsList({required this.discount,required this.image});
}
// Widget get _colorBar=>Container(
//     margin: EdgeInsets.symmetric(horizontal: 30.0),
//     alignment: Alignment.center,
//     width: double.infinity,
//     height: 50.0,
//     decoration: BoxDecoration(
//         borderRadius: BorderRadius.all(Radius.circular(8.0)),
//         gradient: LinearGradient(
//             colors: [
//               Colors.red[100]!,
//               Colors.red[900]!,
//             ]
//         ),
//         boxShadow: [
//           BoxShadow(
//             offset: Offset(0, 0),
//             color: Colors.red[100]!,
//             blurRadius: 16.0,
//           ),
//           BoxShadow(
//             offset: Offset(0, 0),
//             color: Colors.red[200]!,
//             blurRadius: 16.0,
//           ),
//           BoxShadow(
//             offset: Offset(0, 0),
//             color: Colors.red[300]!,
//             blurRadius: 16.0,
//           ),
//         ]
//     ),
//     child: Text("Login", style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 18.0))
// );