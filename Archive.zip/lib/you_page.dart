
import 'package:amazon/customappbar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class YouPage extends StatefulWidget {
  const YouPage({super.key});

  @override
  State<YouPage> createState() => _YouPageState();
}

var size, height, width;
List<String> youItemsName = ["Orders", "Lists", "Account", "Buy Again"];
List<String> yourAccount = ["Your Orders","Your Addresses","View Amazon Pay balance statement","Amazon Pay UPI","Subscribe & Save","Top-up your Amazon Pay Wallet"];
List<YourOrderList> yourOrderItems = [];
List<BuyAgainList> buyAgainItems = [];
List<KeepShopping> shoppingItems = [];
List<YourRewards> rewardItems = [];
class _YouPageState extends State<YouPage> {
  yourOrderItemsList() {
    yourOrderItems.clear();
    yourOrderItems
        .add(YourOrderList(image: "assets/images/yourorder/Wallet.png"));
    yourOrderItems
        .add(YourOrderList(image: "assets/images/yourorder/iphoneX.png"));
    yourOrderItems.add(YourOrderList(image: "assets/images/yourorder/bag.png"));
    setState(() {});
  }

  buyAgainItemsList() {
    buyAgainItems.clear();
    buyAgainItems
        .add(BuyAgainList(image: "assets/images/buyagain/deo.png"));
    buyAgainItems
        .add(BuyAgainList(image: "assets/images/buyagain/playstation.png"));
    setState(() {});
  }

  shoppingItemsList(){
    shoppingItems.clear();
    shoppingItems.add(KeepShopping(name: "Laptops", images: "assets/images/shopping/mac.png", views: "5 viewed"));
    shoppingItems.add(KeepShopping(name: "Watches", images: "assets/images/shopping/rolex.png", views: "6 viewed"));
    shoppingItems.add(KeepShopping(name: "Sunglasses", images: "assets/images/shopping/sunglass.png", views: "2 viewed"));
    setState(() {

    });
  }

  rewardItemsList(){
    rewardItems.clear();
    rewardItems.add(YourRewards(name: "Cashback earned", icon: Icons.currency_rupee, num: "0"));
    rewardItems.add(YourRewards(name: "Collected offers", icon: Icons.local_offer, num: "0"));
    rewardItems.add(YourRewards(name: "Scratch cards", icon: Icons.card_giftcard, num: "1"));
    setState(() {

    });

  }
  @override
  void initState() {
    // TODO: implement initState
    yourOrderItemsList();
    buyAgainItemsList();
    shoppingItemsList();
    rewardItemsList();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    height = size.height;
    width = size.width;
    return SafeArea(
        child: Scaffold(
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CustomAppBar(),
            _TabBarWidget,
            _OptionTabWidget,
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  const Expanded(
                      child: Text(
                    "Your Orders",
                    style:
                        TextStyle(overflow: TextOverflow.ellipsis, fontSize: 15,fontWeight: FontWeight.bold),
                    maxLines: 1,
                  )),
                  GestureDetector(
                      onTap: () {},
                      child: const Text(
                        "See all",
                        style: TextStyle(
                            color: Colors.teal, overflow: TextOverflow.ellipsis),
                        maxLines: 1,
                      )),
                ],
              ),
            ),
            SizedBox(height: height / 6, child: _yourOrdersWidget),
            Divider(thickness: 4,color: Colors.grey[350],),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  const Expanded(
                      child: Text(
                        "Buy Again",
                        style:
                        TextStyle(overflow: TextOverflow.ellipsis, fontSize: 15,fontWeight: FontWeight.bold),
                        maxLines: 1,
                      )),
                  GestureDetector(
                      onTap: () {},
                      child: const Text(
                        "See all",
                        style: TextStyle(
                            color: Colors.teal, overflow: TextOverflow.ellipsis),
                        maxLines: 1,
                      )),
                ],
              ),
            ),
            SizedBox(height: height/6, child: _buyAgainWidget),
            Divider(thickness: 4,color: Colors.grey[350],),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  const Expanded(
                      child: Text(
                        "Keep shopping for",
                        style:
                        TextStyle(overflow: TextOverflow.ellipsis, fontSize: 15,fontWeight: FontWeight.bold),
                        maxLines: 1,
                      )),
                  GestureDetector(
                      onTap: () {},
                      child: const Text(
                        "Edit",
                        style: TextStyle(
                            color: Colors.teal, overflow: TextOverflow.ellipsis),
                        maxLines: 1,
                      )),
                ],
              ),
            ),
            SizedBox(height: height/4.5, child: _keepShoppingForWidget),
             Padding(
              padding: const EdgeInsets.only(left: 8),
              child: GestureDetector(onTap:(){},child: const Text("View your browsing history",style: TextStyle(overflow: TextOverflow.ellipsis,color: Colors.teal),maxLines: 1,)),
            ),
            Divider(thickness: 4,color: Colors.grey[350],),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  const Expanded(
                      child: Text(
                        "Your Lists",
                        style:
                        TextStyle(overflow: TextOverflow.ellipsis, fontSize: 15,fontWeight: FontWeight.bold),
                        maxLines: 1,
                      )),
                  GestureDetector(
                      onTap: () {},
                      child: const Text(
                        "See all",
                        style: TextStyle(
                            color: Colors.teal, overflow: TextOverflow.ellipsis),
                        maxLines: 1,
                      )),
                ],
              ),
            ),
            _YourListWidget,
            Divider(thickness: 4,color: Colors.grey[350],),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  const Expanded(
                      child: Text(
                        "Your Account",
                        style:
                        TextStyle(overflow: TextOverflow.ellipsis, fontSize: 15,fontWeight: FontWeight.bold),
                        maxLines: 1,
                      )),
                  GestureDetector(
                      onTap: () {},
                      child: const Text(
                        "See all",
                        style: TextStyle(
                            color: Colors.teal, overflow: TextOverflow.ellipsis),
                        maxLines: 1,
                      )),
                ],
              ),
            ),
            SizedBox(height: height/12, child: _YourAccountWidget),
            Divider(thickness: 4,color: Colors.grey[350],),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  const Expanded(
                      child: Text(
                        "Your Rewards",
                        style:
                        TextStyle(overflow: TextOverflow.ellipsis, fontSize: 15,fontWeight: FontWeight.bold),
                        maxLines: 1,
                      )),
                  GestureDetector(
                      onTap: () {},
                      child: const Text(
                        "See all",
                        style: TextStyle(
                            color: Colors.teal, overflow: TextOverflow.ellipsis),
                        maxLines: 1,
                      )),
                ],
              ),
            ),
            SizedBox(height: height/9, child: _YourRewardsWidget),
            Divider(thickness: 4,color: Colors.grey[350],),
            const Padding(
              padding: EdgeInsets.all(8.0),
              child: Expanded(
                  child: Text(
                    "Need more help?",
                    style:
                    TextStyle(overflow: TextOverflow.ellipsis, fontSize: 15,fontWeight: FontWeight.bold),
                    maxLines: 1,
                  )),
            ),
            _NeedHelpWidget,
            Divider(thickness: 4,color: Colors.grey[350],),
          ],
        ),
      ),
    ));
  }
}

Widget get _TabBarWidget => Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(
            height: 30,
            width: 130,
            child: GestureDetector(
              onTap: () {},
              child: Row(
                children: [
                  Container(
                    decoration: BoxDecoration(
                        color: Colors.teal,
                        shape: BoxShape.circle,
                        border: Border.all(width: 1, color: Colors.grey)),
                    child: const Icon(
                      Icons.person,
                      color: Colors.white70,
                    ),
                  ),
                  const Spacer(),
                  const Text(
                    "Hello, Joker",
                    style: TextStyle(overflow: TextOverflow.ellipsis),
                    maxLines: 1,
                  ),
                  const Icon(Icons.arrow_drop_down),
                ],
              ),
            ),
          ),
          Spacer(),
          IconButton(onPressed: () {}, icon: Icon(Icons.settings)),
          IconButton(onPressed: () {}, icon: Icon(Icons.notifications_none)),
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                height: 20,
                width: 20,
                decoration: const BoxDecoration(
                  shape: BoxShape.rectangle,
                  image: DecorationImage(
                      image: AssetImage("assets/icons/flag.png"),
                      fit: BoxFit.contain),
                ),
              ),
              SizedBox(
                width: 5,
              ),
              Text(
                "EN",
                overflow: TextOverflow.ellipsis,
                maxLines: 1,
              ),
            ],
          ),
        ],
      ),
    );

Widget get _OptionTabWidget => Padding(
      padding: const EdgeInsets.all(8.0),
      child: GridView.builder(
        shrinkWrap: true,
        physics: NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2, // number of items in each row
            mainAxisSpacing: 8.0, // spacing between rows
            crossAxisSpacing: 8.0,
            mainAxisExtent: 40 // spacing between columns
            ),
        padding: const EdgeInsets.all(8.0),
        // padding around the grid
        itemCount: youItemsName.length,
        // total number of items
        itemBuilder: (context, index) {
          return Container(
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                shape: BoxShape.rectangle,
                border: Border.all(width: 1)),
            child: Center(child: Text(youItemsName[index])),
          );
        },
      ),
    );

Widget get _yourOrdersWidget => Padding(
      padding: const EdgeInsets.all(8.0),
      child: ListView.builder(
          itemCount: 4,
          shrinkWrap: true,
          scrollDirection: Axis.horizontal,
          itemBuilder: (context, index) {
            return index == 0 || index == 1 || index == 2
                ? Container(
                    width: 150,
                    margin: EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(width: 0.5, color: Colors.grey),
                      image: DecorationImage(
                          image: AssetImage(yourOrderItems[index].image),
                          fit: BoxFit.contain),
                    ),
                  )
                : Container(
                    width: 150,
                    margin: EdgeInsets.all(5),
                    padding: EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(width: 0.5, color: Colors.grey),
                    ),
                    child: Column(
                      children: [
                        const SizedBox(
                          height: 5,
                        ),
                        const Text(
                          "Can't find the order?",
                          overflow: TextOverflow.ellipsis,
                          maxLines: 1,
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        TextFormField(
                          textInputAction: TextInputAction.done,
                          decoration: InputDecoration(
                            contentPadding: const EdgeInsets.all(5),
                            prefixIcon: const Icon(
                              Icons.search,
                              color: Colors.black,
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                color: Colors.teal,
                              ),
                              borderRadius: BorderRadius.circular(10.0),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                  width: 1, color: Colors.grey),
                              //<-- SEE HERE
                              borderRadius: BorderRadius.circular(10.0),
                            ),
                            hintText: 'Search orders',
                            hintStyle: const TextStyle(
                                color: Colors.black54,
                                fontSize: 12,
                                overflow: TextOverflow.ellipsis),
                          ),
                          maxLines: 1,
                        ),
                      ],
                    ),
                  );
          }),
    );

Widget get _buyAgainWidget => Padding(
  padding: const EdgeInsets.all(8.0),
  child: ListView.builder(
      itemCount: buyAgainItems.length,
      shrinkWrap: true,
      scrollDirection: Axis.horizontal,
      itemBuilder: (context, index) {
        return Container(
          width: 120,
          margin: EdgeInsets.all(5),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            border: Border.all(width: 0.5, color: Colors.grey),
            image: DecorationImage(
                image: AssetImage(buyAgainItems[index].image),
                fit: BoxFit.contain),
          ),
        );
      }),
);

Widget get _keepShoppingForWidget => Padding(
  padding: const EdgeInsets.all(8.0),
  child: ListView.builder(
      itemCount: shoppingItems.length,
      shrinkWrap: true,
      scrollDirection: Axis.horizontal,
      itemBuilder: (context, index) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 120,
              height: 100,
              margin: EdgeInsets.all(5),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                border: Border.all(width: 0.5, color: Colors.grey),
                image: DecorationImage(
                    image: AssetImage(shoppingItems[index].images),
                    fit: BoxFit.contain),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 5),
              child: Text(shoppingItems[index].name,style: const TextStyle(overflow: TextOverflow.ellipsis),maxLines: 1,),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 5),
              child: Text(shoppingItems[index].views,style: const TextStyle(color: Colors.grey,fontSize: 10),maxLines: 1,),
            )
          ],
        );
      }),
);

Widget get _YourListWidget => Padding(
  padding: const EdgeInsets.all(8.0),
  child: GestureDetector(
    onTap: (){},
    child: Container(
            width: 400,
            margin: EdgeInsets.only(left: 10,right: 10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(5),
              border: Border.all(width: 0.5, color: Colors.grey),
            ),
      child:  const Row(
        children: [
          Padding(
            padding: EdgeInsets.all(8.0),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Shopping List",style: TextStyle(overflow: TextOverflow.ellipsis),maxLines: 1,),
                Text("Private . Default",style: TextStyle(overflow: TextOverflow.ellipsis,fontSize: 10,color: Colors.grey),maxLines: 1,),
              ],
            ),
          ),
          Spacer(),
          Padding(
            padding: EdgeInsets.all(8.0),
            child: Icon(Icons.my_library_books_outlined,color: Colors.grey,size: 50,),
          )
        ],
      ),
          ),
  ),
      );

Widget get _YourAccountWidget => Padding(
  padding: const EdgeInsets.all(8.0),
  child: ListView.builder(
      itemCount: yourAccount.length,
      shrinkWrap: true,
      scrollDirection: Axis.horizontal,
      itemBuilder: (context, index) {
        return Container(
          margin: EdgeInsets.all(5),
          padding: EdgeInsets.all(5),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            border: Border.all(width: 0.5, color: Colors.grey),
          ),
          child: Center(
            child: Text(yourAccount[index],style: TextStyle(color: Colors.black),),
          ),
        );
      }),
);

Widget get _YourRewardsWidget => Padding(
  padding: const EdgeInsets.all(8.0),
  child: Container(
    width: 400,
margin: EdgeInsets.only(left: 10,right: 10),
decoration: BoxDecoration(
borderRadius: BorderRadius.circular(5),
border: Border.all(width: 0.5, color: Colors.grey),
),child: ListView.builder(
    itemCount: rewardItems.length,
    shrinkWrap: true,
    scrollDirection: Axis.horizontal,
    physics: NeverScrollableScrollPhysics(),
    itemBuilder: (BuildContext context, int index) {
      return
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
            children: [
              GestureDetector(
                onTap: (){},
                child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(rewardItems[index].name,style: TextStyle(overflow: TextOverflow.ellipsis,fontSize: 12),maxLines: 1,),
                    Row(
                      children: [
                        Icon(rewardItems[index].icon,color: Colors.amber,size: 15,),
                        SizedBox(width: 5,),
                        Text(rewardItems[index].num)
                      ],
                    )
                  ],
                ),
              ),
            ],
                    ),
          );
    },
  ),),
);

Widget get _NeedHelpWidget => Padding(
  padding: const EdgeInsets.all(8.0),
  child: GestureDetector(
    onTap: (){},
    child: Container(
      width: 170,
            height: 50,
            margin: const EdgeInsets.all(5),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              border: Border.all(width: 0.5, color: Colors.grey),
            ),
            child: const Center(
              child: Text("Visit customer service",style: TextStyle(color: Colors.black,overflow: TextOverflow.ellipsis),maxLines: 1,),
            ),
          ),
  ),
);

class YourOrderList {
  String image;

  YourOrderList({required this.image});
}
class BuyAgainList {
  String image;

  BuyAgainList({required this.image});
}
class KeepShopping{
  String images;
  String name;
  String views;
  KeepShopping({required this.name,required this.images,required this.views});
}
class YourRewards{
  String name;
  IconData icon;
  String num;
  YourRewards({required this.name,required this.icon,required this.num});
}

