import 'package:amazon/customappbar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';

class CartPage extends StatefulWidget {
  const CartPage({super.key});

  @override
  State<CartPage> createState() => _CartPageState();
}
var size, height, width;
List<CartItems> recItems = [];
List<CartItems> customerItems = [];
List<CartItems> topPickItems = [];
List<CartItems> relevantItems = [];
class _CartPageState extends State<CartPage> {
  recommendItemsList() {
    recItems.clear();
    recItems.add(CartItems(
        image: "assets/images/yourorder/Wallet.png", name: "Leather Wallet", price: "1,100", rating: "1,022", soldCount: "2K"));
    recItems.add(CartItems(
        image: "assets/images/shopping/mac.png", name: "Apple MacBook Air", price: "56,990", rating: "4,768", soldCount: "5K"));
    recItems.add(CartItems(
        image: "assets/images/buyagain/playstation.png", name: "Play Station 5", price: "46,999", rating: "2,203", soldCount: "10K"));
    recItems.add(CartItems(
        image: "assets/images/buyagain/deo.png", name: "Nivea Men Deodorant", price: "597", rating: "1,000", soldCount: "500"));
   setState(() {

   });
  }
  customerItemsList(){
    customerItems.clear();
    customerItems.add(CartItems(image: "assets/images/cartimages/bodywash.png", name: "Nivea Men Body wash", price: "250", rating: "500", soldCount: "2K"));
    customerItems.add(CartItems(image: "assets/images/cartimages/casiowatch.png", name: "Casio Digital W-190", price: "1,599", rating: "4,300", soldCount: "5K"));
    customerItems.add(CartItems(image: "assets/images/cartimages/charger.png", name: "Iphone Charger with Lightening Cable", price: "2,000", rating: "3,500", soldCount: "3K"));
    setState(() {

    });
  }
  topPickList(){
    topPickItems.clear();
    topPickItems.add(CartItems(image: "assets/images/cartimages/xbox.png", name: "X-Box Gaming Console", price: "46,999", rating: "4,900", soldCount: "10K"));
    topPickItems.add(CartItems(image: "assets/images/cartimages/gamingpc.png", name: "Gaming PC", price: "89,999", rating: "1,500", soldCount: "5K"));
    topPickItems.add(CartItems(image: "assets/images/cartimages/iphone.png", name: "iphone 13 Pro", price: "89,000", rating: "10,358", soldCount: "10K"));
    setState(() {

    });
  }
  relevantItemsList(){
    relevantItems.clear();
    relevantItems.add(CartItems(image: "assets/images/cartimages/casioanalog.png", name: "Casio Analog A-1200", price: "6,999", rating: "400", soldCount: "1K"));
    relevantItems.add(CartItems(image: "assets/images/cartimages/gshock.png", name: "G-Shock Casio", price: "11,050", rating: "1,235", soldCount: "2K"));
    relevantItems.add(CartItems(image: "assets/images/cartimages/g-shock.png", name: "Casio G-Shock", price: "10,200", rating: "700", soldCount: "500"));
    setState(() {

    });
  }
@override
  void initState() {
    // TODO: implement initState
  recommendItemsList();
  customerItemsList();
  topPickList();
  relevantItemsList();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    height = size.height;
    width = size.width;
    return SafeArea(
        child: Scaffold(
      backgroundColor: Colors.grey[300],
      body: SingleChildScrollView(
        child: Column(
          children: [
            CustomAppBar(),
            _bottomTabWidget,
            _recommendWidget,
            _CustomerBoughtWidget,
            _TopPicksWidget,
            _relevantItemsWidget,
            _continueShopping
          ],
        ),
      ),
    ));
  }
}

Widget get _bottomTabWidget => Container(
      height: 110,
      color: Colors.white,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            height: 60,
            width: 60,
            child: Image(
              image: AssetImage("assets/images/cartimages/carts.png"),
            ),
          ),
          SizedBox(
            width: 40,
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "Your Amazon Cart is\nempty",
                style: TextStyle(fontSize: 20),
                maxLines: 2,
              ),
              SizedBox(
                height: 10,
              ),
              GestureDetector(
                  onTap: () {},
                  child: Text(
                    "Pick up where you left off",
                    style: TextStyle(color: Colors.teal),
                    maxLines: 1,
                  )),
            ],
          ),
        ],
      ),
    );

Widget get _recommendWidget => Container(
  height: 350,padding: EdgeInsets.all(10),
  margin: EdgeInsets.only(left: 15,right: 15,top: 15),
      color: Colors.white,
      child: Column(mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Row(
            children: [
              Expanded(
                  child: Text(
                "Recommendations for all\nproducts:",
                style: TextStyle(
                    overflow: TextOverflow.ellipsis,
                    fontWeight: FontWeight.bold,fontSize: 20),
                maxLines: 2,
              )),
              IconButton(onPressed: () {}, icon: Icon(Icons.more_vert))
            ],
          ),
          Expanded(
            child: ListView.builder(
              itemCount: recItems.length,
                shrinkWrap: true,
                scrollDirection: Axis.horizontal,
                itemBuilder: (context, index) {
                  return Container(
                    margin: EdgeInsets.all(10),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          height:100,
                          width: 100,
                          margin: EdgeInsets.all(5),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            image: DecorationImage(
                                image: AssetImage(recItems[index].image),
                                fit: BoxFit.contain),
                          ),
                        ),
                        SizedBox(width: 100, child: Text(recItems[index].name,style: TextStyle(color: Colors.teal,overflow: TextOverflow.ellipsis),maxLines: 1,)),
                        Row(
                          children: [
                            RatingBar.builder(
                              itemSize: 10,
                              initialRating: 3,
                              minRating: 1,
                              direction: Axis.horizontal,
                              allowHalfRating: true,
                              itemCount: 5,
                              itemPadding: EdgeInsets.symmetric(horizontal: 1.0),
                              itemBuilder: (context, _) => const Icon(
                                Icons.star,
                                color: Colors.orange,
                              ),
                              onRatingUpdate: (rating) {
                                print(rating);
                              },
                            ),
                            Text(recItems[index].rating,style: TextStyle(color: Colors.teal,overflow: TextOverflow.ellipsis),maxLines: 1,),
            
                          ],
                        ),
                        Text("${recItems[index].soldCount}+ bought in past\nmonth",style: TextStyle(color: Colors.grey),maxLines: 2,),
                        SizedBox(height: 5,),
                        Text("Rs.${recItems[index].price}.00",style: TextStyle(color: Colors.red,overflow: TextOverflow.ellipsis),maxLines: 1,),
                       SizedBox(height: 5,),
                        _checkBoxButton
                      ],
                    ),
                  );
                }),
          )
        ],
      ),
    );

Widget get _CustomerBoughtWidget => Container(
  height: 350,padding: EdgeInsets.all(10),
  margin: EdgeInsets.only(left: 15,right: 15,top: 15),
  color: Colors.white,
  child: Column(mainAxisAlignment: MainAxisAlignment.center,
    children: [
      Row(
        children: [
          Expanded(
              child: Text(
                "Customer who bought items in\nyour Recent History also bought",
                style: TextStyle(
                    overflow: TextOverflow.ellipsis,
                    fontWeight: FontWeight.bold,fontSize: 20),
                maxLines: 2,
              )),
          IconButton(onPressed: () {}, icon: Icon(Icons.more_vert))
        ],
      ),
      Expanded(
        child: ListView.builder(
            itemCount: customerItems.length,
            shrinkWrap: true,
            scrollDirection: Axis.horizontal,
            itemBuilder: (context, index) {
              return Container(
                margin: EdgeInsets.all(10),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      height:100,
                      width: 100,
                      margin: EdgeInsets.all(5),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        image: DecorationImage(
                            image: AssetImage(customerItems[index].image),
                            fit: BoxFit.contain),
                      ),
                    ),
                    SizedBox(width:100,child: Text(customerItems[index].name,style: TextStyle(color: Colors.teal,overflow: TextOverflow.ellipsis),maxLines: 1,)),
                    Row(
                      children: [
                        RatingBar.builder(
                          itemSize: 10,
                          initialRating: 3,
                          minRating: 1,
                          direction: Axis.horizontal,
                          allowHalfRating: true,
                          itemCount: 5,
                          itemPadding: EdgeInsets.symmetric(horizontal: 1.0),
                          itemBuilder: (context, _) => const Icon(
                            Icons.star,
                            color: Colors.orange,
                          ),
                          onRatingUpdate: (rating) {
                            print(rating);
                          },
                        ),
                        Text(customerItems[index].rating,style: TextStyle(color: Colors.teal,overflow: TextOverflow.ellipsis),maxLines: 1,),

                      ],
                    ),
                    Text("${customerItems[index].soldCount}+ bought in past\nmonth",style: TextStyle(color: Colors.grey),maxLines: 2,),
                    SizedBox(height: 5,),
                    Text("Rs.${customerItems[index].price}.00",style: TextStyle(color: Colors.red,overflow: TextOverflow.ellipsis),maxLines: 1,),
                    SizedBox(height: 5,),
                    _checkBoxButton
                  ],
                ),
              );
            }),
      )
    ],
  ),
);

Widget get _TopPicksWidget => Container(
  height: 350,padding: EdgeInsets.all(10),
  margin: EdgeInsets.only(left: 15,right: 15,top: 15),
  color: Colors.white,
  child: Column(mainAxisAlignment: MainAxisAlignment.center,
    children: [
      Row(
        children: [
          Expanded(
              child: Text(
                "Top picks for you",
                style: TextStyle(
                    overflow: TextOverflow.ellipsis,
                    fontWeight: FontWeight.bold,fontSize: 20),
                maxLines: 2,
              )),
          IconButton(onPressed: () {}, icon: Icon(Icons.more_vert))
        ],
      ),
      Expanded(
        child: ListView.builder(
            itemCount: topPickItems.length,
            shrinkWrap: true,
            scrollDirection: Axis.horizontal,
            itemBuilder: (context, index) {
              return Container(
                margin: EdgeInsets.all(10),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      height:100,
                      width: 100,
                      margin: EdgeInsets.all(5),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        image: DecorationImage(
                            image: AssetImage(topPickItems[index].image),
                            fit: BoxFit.contain),
                      ),
                    ),
                    SizedBox(width:100,child: Text(topPickItems[index].name,style: TextStyle(color: Colors.teal,overflow: TextOverflow.ellipsis),maxLines: 1,)),
                    Row(
                      children: [
                        RatingBar.builder(
                          itemSize: 10,
                          initialRating: 3,
                          minRating: 1,
                          direction: Axis.horizontal,
                          allowHalfRating: true,
                          itemCount: 5,
                          itemPadding: EdgeInsets.symmetric(horizontal: 1.0),
                          itemBuilder: (context, _) => const Icon(
                            Icons.star,
                            color: Colors.orange,
                          ),
                          onRatingUpdate: (rating) {
                            print(rating);
                          },
                        ),
                        Text(topPickItems[index].rating,style: TextStyle(color: Colors.teal,overflow: TextOverflow.ellipsis),maxLines: 1,),

                      ],
                    ),
                    Text("${topPickItems[index].soldCount}+ bought in past\nmonth",style: TextStyle(color: Colors.grey),maxLines: 2,),
                    SizedBox(height: 5,),
                    Text("Rs.${topPickItems[index].price}.00",style: TextStyle(color: Colors.red,overflow: TextOverflow.ellipsis),maxLines: 1,),
                    SizedBox(height: 5,),
                    _checkBoxButton
                  ],
                ),
              );
            }),
      )
    ],
  ),
);

Widget get _relevantItemsWidget =>  Container(
  height: 350,padding: EdgeInsets.all(10),
  margin: EdgeInsets.all(15),
  color: Colors.white,
  child: Column(mainAxisAlignment: MainAxisAlignment.center,
    children: [
      Row(
        children: [
          Expanded(
              child: Text(
                "Relevant items that may ship\ntogether",
                style: TextStyle(
                    overflow: TextOverflow.ellipsis,
                    fontWeight: FontWeight.bold,fontSize: 20),
                maxLines: 2,
              )),
          IconButton(onPressed: () {}, icon: Icon(Icons.more_vert))
        ],
      ),
      Expanded(
        child: ListView.builder(
            itemCount: relevantItems.length,
            shrinkWrap: true,
            scrollDirection: Axis.horizontal,
            itemBuilder: (context, index) {
              return Container(
                margin: EdgeInsets.all(10),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      height:100,
                      width: 100,
                      margin: EdgeInsets.all(5),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        image: DecorationImage(
                            image: AssetImage(relevantItems[index].image),
                            fit: BoxFit.contain),
                      ),
                    ),
                    SizedBox(width:100,child: Text(relevantItems[index].name,style: TextStyle(color: Colors.teal,overflow: TextOverflow.ellipsis),maxLines: 1,)),
                    Row(
                      children: [
                        RatingBar.builder(
                          itemSize: 10,
                          initialRating: 3,
                          minRating: 1,
                          direction: Axis.horizontal,
                          allowHalfRating: true,
                          itemCount: 5,
                          itemPadding: EdgeInsets.symmetric(horizontal: 1.0),
                          itemBuilder: (context, _) => const Icon(
                            Icons.star,
                            color: Colors.orange,
                          ),
                          onRatingUpdate: (rating) {
                            print(rating);
                          },
                        ),
                        Text(relevantItems[index].rating,style: TextStyle(color: Colors.teal,overflow: TextOverflow.ellipsis),maxLines: 1,),

                      ],
                    ),
                    Text("${relevantItems[index].soldCount}+ bought in past\nmonth",style: TextStyle(color: Colors.grey),maxLines: 2,),
                    SizedBox(height: 5,),
                    Text("Rs.${relevantItems[index].price}.00",style: TextStyle(color: Colors.red,overflow: TextOverflow.ellipsis),maxLines: 1,),
                    SizedBox(height: 5,),
                    _checkBoxButton
                  ],
                ),
              );
            }),
      )
    ],
  ),
);

Widget get _checkBoxButton => SizedBox(
  height: 30,
  width: 100,
  child: Builder(builder: (context) {
    return ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.amberAccent,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20.0),
          ), // Background color
        ),
        onPressed: () {
        },
        child: const Text(
          "Add to cart",
          style: TextStyle(
              color: Colors.black, overflow: TextOverflow.ellipsis,fontSize: 10),
          maxLines: 1,
        ));
  }),
);

Widget get _continueShopping => Container(
  color: Colors.white,
  width: width,
  child: Builder(builder: (context) {
    return Container(
      margin: EdgeInsets.only(left: 15,right: 15,top: 15),
      child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.amberAccent,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20.0),
            ), // Background color
          ),
          onPressed: () {
          },
          child: const Text(
            "Continue shopping",
            style: TextStyle(
                color: Colors.black, overflow: TextOverflow.ellipsis,),
            maxLines: 1,
          )),
    );
  }),
);

class CartItems {
  String image;
  String name;
  String rating;
  String soldCount;
  String price;

  CartItems(
      {required this.image,
      required this.name,
      required this.price,
      required this.rating,
      required this.soldCount});
}
