import 'package:amazon/cart_page.dart';
import 'package:amazon/home_page.dart';
import 'package:amazon/menu_page.dart';
import 'package:amazon/you_page.dart';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';

import 'more_page.dart';

class Amazon extends StatefulWidget {
  @override
  _AmazonState createState() => _AmazonState();
}
List<MoreButtonItems> moreItems = [];
class _AmazonState extends State<Amazon> {

  moreItemsList(){
    moreItems.clear();
    moreItems.add(MoreButtonItems(name: "Pay Bills, Send\nMoney & more", image: "assets/images/moreicons/social.png"));
    moreItems.add(MoreButtonItems(name: "Watch Free\nShows & more", image: "assets/images/moreicons/mini.png"));
    moreItems.add(MoreButtonItems(name: "Book Travel\ntickets", image: "assets/images/moreicons/logistics.png"));
    moreItems.add(MoreButtonItems(name: "Play &\nWin Prizes", image: "assets/images/moreicons/wingame.png"));
    setState(() {

    });
  }
  @override
  void initState() {
    // TODO: implement initState
    moreItemsList();
    super.initState();
  }

  int _currentIndex = 0;
  final _screens = [
    HomePage(),
    YouPage(),
    MorePage(), // Uncomment when MorePage is ready
    CartPage(),
    MenuPage(),
    Rufus(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_currentIndex],
      bottomNavigationBar: CustomBottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
      ),
    );
  }
}

class CustomBottomNavigationBar extends StatelessWidget {

  final int currentIndex;
  final Function(int) onTap;

  const CustomBottomNavigationBar({
    super.key,
    required this.currentIndex,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {

    return Container(
      height: 60,
      decoration: const BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(color: Colors.black12, spreadRadius: 1, blurRadius: 10),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          CustomNavigationBarItem(
            icon: Icons.home,
            label: 'Home',
            isSelected: currentIndex == 0,
            onTap: () => onTap(0),
          ),
          CustomNavigationBarItem(
            icon: Icons.person_outline,
            label: 'You',
            isSelected: currentIndex == 1,
            onTap: () => onTap(1),
          ),
          CustomNavigationBarItem(
            icon: Icons.more_outlined,
            label: 'More',
            isSelected: currentIndex == 2,
            onTap: () {
              showModalBottomSheet<void>(
                backgroundColor: Colors.white,
                context: context,
                useRootNavigator: true,
                builder: (BuildContext context) {
                  final bottomNavHeight = MediaQuery.of(context).padding.bottom;
                  return Container(
                    padding: EdgeInsets.only(bottom: bottomNavHeight + 20),
                    margin: const EdgeInsets.symmetric(horizontal: 20),
                    height: 360,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        SizedBox(height: 5,),
                        Center(
                          child: Container(
                            height: 5,
                            width: 40,
                            decoration: BoxDecoration(
                              shape: BoxShape.rectangle,
                              color: Colors.grey[400],
                              borderRadius: BorderRadius.circular(10)
                            ),
                          ),
                        ),
                        SizedBox(height: 10,),
                        const Text(
                          'Do more with Amazon',
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 16),
                        _ScanCodeMoreWidget,
                        SizedBox(height: 10,),
                        _MoreItemsWidget

                      ],
                    ),
                  );
                },
              );
            },
          ),
          CustomNavigationBarItem(
            icon: Icons.shopping_cart_outlined,
            label: 'Cart',
            isSelected: currentIndex == 3,
            onTap: () => onTap(3),
          ),
          CustomNavigationBarItem(
            icon: Icons.menu,
            label: 'Menu',
            isSelected: currentIndex == 4,
            onTap: () => onTap(4),
          ),
          CustomNavigationBarItem(
            icon: Icons.alternate_email,
            label: 'Rufus',
            isSelected: currentIndex == 5,
            onTap: () => onTap(5),
          ),
        ],
      ),
    );
  }
}

class CustomNavigationBarItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isSelected;
  final Function onTap;

  const CustomNavigationBarItem({
    required this.icon,
    required this.label,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => onTap(),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 20, color: isSelected ? Colors.teal : Colors.black),
          Text(label, style: TextStyle(color: isSelected ? Colors.teal : Colors.black)),
        ],
      ),
    );
  }
}

class Rufus extends StatelessWidget {
  const Rufus({super.key});

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      body: Center(
        child: Text("Home"),
      ),
    );
  }
}
Widget get _ScanCodeMoreWidget=>Container(
  height: 100,
  width: 400,
  decoration: BoxDecoration(
    border: Border.all(width: 1,color: Colors.grey),
    gradient: LinearGradient(
        colors: [
          Colors.teal[50]!,
          Colors.teal[100]!,
        ]
    ),
    boxShadow: [
      BoxShadow(
        offset: Offset(0, 0),
        color: Colors.tealAccent[200]!,
        blurRadius: 16.0,
      ),],
    borderRadius: BorderRadius.circular(5),
  ),
  child: Column(crossAxisAlignment: CrossAxisAlignment.center,
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      Icon(Icons.qr_code_scanner_rounded,color: Colors.amber,size: 40,),
      SizedBox(height: 10,),
      Text("Scan any QR to Pay",style: TextStyle(color: Colors.teal,overflow: TextOverflow.ellipsis),maxLines: 1,),
    ],
  ),
);
Widget get _MoreItemsWidget => GridView.builder(

  shrinkWrap: true,
  physics: NeverScrollableScrollPhysics(),
  gridDelegate:  SliverGridDelegateWithFixedCrossAxisCount(
    crossAxisCount: 2, // number of items in each row
    mainAxisSpacing: 8.0, // spacing between rows
    crossAxisSpacing: 8.0,
      mainAxisExtent: 70,

    // spacing between columns
  ),
  itemCount: moreItems.length,
  // total number of items
  itemBuilder: (context, index) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        shape: BoxShape.rectangle,
        border: Border.all(width: 1, color: Colors.grey),
        //color: Colors.grey[50],
        gradient: LinearGradient(colors: [
          Colors.tealAccent[100]!,
          Colors.teal[50]!,
        ]),
        boxShadow: [
          BoxShadow(
            offset: Offset(0, 0),
            color: Colors.teal[50]!,
            blurRadius: 16.0,
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            margin: EdgeInsets.all(10),
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(width: 0.5,color: Colors.grey),
              image: DecorationImage(
                  image: AssetImage(moreItems[index].image),
                  fit: BoxFit.contain),
            ),
          ),
          AutoSizeText(
            moreItems[index].name,
            style: TextStyle(overflow: TextOverflow.ellipsis,fontSize: 10),maxLines: 2,
          ),
        ],
      ),
    );
  },
);
class MoreButtonItems{
  String image;
  String name;
  MoreButtonItems({required this.name,required this.image});
}