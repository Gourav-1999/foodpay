import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class CustomAppBar extends StatelessWidget {
  var size, height, width;

  CustomAppBar({super.key});

  @override
  Widget build(BuildContext context) {
    size = MediaQuery
        .of(context)
        .size;
    height = size.height;
    width = size.width;
    return Container(
      height: 80,
      decoration: const BoxDecoration(
        image: DecorationImage(
          image: AssetImage("assets/colors/teal.png"),
          fit: BoxFit.cover,
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: Container(
              margin: const EdgeInsets.only(left: 10),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10)
              ),
              child:
              TextFormField(

                textInputAction: TextInputAction.done,
                decoration:  InputDecoration(
                  contentPadding: const EdgeInsets.all(10),
                  prefixIcon: const Icon(
                    Icons.search,
                    color: Colors.black,
                  ),
                  suffixIcon:  SizedBox(
                    height: 30,
                    width: 100,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        GestureDetector(onTap:(){},child: const Icon(Icons.camera_alt_outlined, color: Colors.grey,)),
                        GestureDetector(onTap:(){},child: const Icon(Icons.mic_none, color: Colors.grey,))
                      ],
                    ),
                  ),
                  // suffix: Icon(Icons.qr_code_scanner_outlined,color: Colors.black,),
                 // border: OutlineInputBorder(),
                  border: InputBorder.none,
                  enabledBorder: OutlineInputBorder(
                    borderSide:
                    const BorderSide(width: 1, color: Colors.grey), //<-- SEE HERE
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  hintText: 'Search or ask a question',
                  hintStyle: const TextStyle(
                      color: Colors.black54,
                      overflow: TextOverflow.ellipsis),
                ),
                maxLines: 1,
              ),

            ),
          ),
         IconButton(onPressed: (){}, icon: Icon(Icons.qr_code_scanner_rounded,color: Colors.black,))
        ],
      ),
    );
  }
}


